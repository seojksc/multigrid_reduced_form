%
% two dimensional nonlinear partial differential equation by Finite element method with linear polynomials
% -u'' = 0  in (0, 1)
%  u(0) = 0 = u(1)
%
%
%
%
% 2022.02.25.(Fri)
%
% by J.-K. Seo
%

clear all



node = [21];
    for k_node = 1:length(node)
        w0 = load('w0_48');
        v0 = load('v0_48');
        w = w0.w;
        v = v0.v;
        [h1_err,l2_err] = ann_2d_MG_GD(node(k_node),24,10^(-10),0.01,w(1:24,:),sqrt(48)/sqrt(24)*v(1:24,:));
    end 




return

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all

% figure(1); clf;
% figure(2); clf;
% figure(3); clf;
figure(4); clf;
figure(3); clf;

%node = [8; 12; 16; 20; 24; 28; 32; 36; 40; 50; 60; 70];
node = [8; 12; 16; 20; 24; 28; 32; 36; 40; 50; 60; 70];
hidden = [4; 6; 8; 12; 16; 20; 30; 40; 50]; 

for h_ = 1:length(hidden)
for k_node = 1:length(node)
    iter_error = [];
%    loss = zeros(11000,100);
%    loss = zeros(1,100);
    iter_error_multi = [];
%    loss_multi = zeros(11000,100);
%    loss_multi = zeros(1,100);
    for i_loop = 1:100
        w = 1/10*rand(hidden(h_),3);
        v = 1/10*rand(hidden(h_),1);
        perm_ = randperm(node(k_node)+1);
        [iter_total,time_total,loss_total,l2_err,h1_err] = fem1dim_opt11_ann5_multigrid_BFGS2(node(k_node),hidden(h_),1,0.00001,w,v); 
        iter_error_multi = [iter_error_multi; [iter_total time_total loss_total l2_err h1_err]];
%        iter_loss_multi = [iter_loss_multi [iter_total(:) loss_total(:)]];
%        loss_multi(1:length(loss_total(:)),i_loop) = loss_total(:);
%        loss_multi(i_loop) = loss_total;
        
        [iter_total,time_total,loss_total,l2_err,h1_err] = fem1dim_opt11_ann5_BFGS(node(k_node),hidden(h_),1,0.00001,w,v); 
        iter_error = [iter_error; [iter_total time_total loss_total l2_err h1_err]];
%        iter_loss = [iter_loss [iter_total(:) loss_total(:)]];
%        loss(1:length(loss_total(:)),i_loop) = loss_total(:);
%        loss(i_loop) = loss_total;
        
        i_loop
    end
    csvwrite(sprintf('C:/Users/Seo/Desktop/Matlab/FEM1dim/For paper work/Result_weights/randperm_iteration_2D/fem1dim_opt11_ann5_multigrid_BFGS2_hidden%s_loss1_coarse1_fine30_coarse2_fine30_iteration_time/fem1dim_opt11_ann5_BFGS3_%s_%s_1_0p00001_iteration_L2_H1',num2str(hidden(h_)),num2str(node(k_node)),num2str(hidden(h_))), iter_error);
%    csvwrite(sprintf('C:/Users/Seo/Desktop/Matlab/FEM1dim/For paper work/Result_weights/randperm_iteration_1D/fem1dim_opt11_ann4_multigrid_BFGS2_hidden%s_loss1_coarse1_fine30_coarse2_fine30_iteration_time/fem1dim_opt11_ann4_BFGS3_%s_%s_1_0p00001_iteration_loss',num2str(hidden(h_)),num2str(node(k_node)),num2str(hidden(h_))), loss);
    csvwrite(sprintf('C:/Users/Seo/Desktop/Matlab/FEM1dim/For paper work/Result_weights/randperm_iteration_2D/fem1dim_opt11_ann5_multigrid_BFGS2_hidden%s_loss1_coarse1_fine30_coarse2_fine30_iteration_time/fem1dim_opt11_ann5_multigrid_BFGS2_%s_%s_1_0p00001_iteration_L2_H1',num2str(hidden(h_)),num2str(node(k_node)),num2str(hidden(h_))), iter_error_multi);
%    csvwrite(sprintf('C:/Users/Seo/Desktop/Matlab/FEM1dim/For paper work/Result_weights/randperm_iteration_1D/fem1dim_opt11_ann4_multigrid_BFGS2_hidden%s_loss1_coarse1_fine30_coarse2_fine30_iteration_time/fem1dim_opt11_ann4_multigrid_BFGS2_%s_%s_1_0p00001_iteration_loss',num2str(hidden(h_)),num2str(node(k_node)),num2str(hidden(h_))), loss_multi);
end
end

return







