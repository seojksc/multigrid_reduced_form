%
% two dimensional nonlinear partial differential equation by Finite element method with linear polynomials
% -u'' = 0  in (0, 1)
%  u(0) = 0 = u(1)
%
%
%
%
% 2022.02.25.(Fri)
%
% by J.-K. Seo
%

clear all



node = [21];

    for k_node = 1:length(node)
        w0 = load('w0_48');
        v0 = load('v0_48');
        w = w0.w;
        v = v0.v;
        [h1_err,l2_err] = ann_2d_GD(node(k_node),24,10^(-10),0.01,w(1:24,:),sqrt(48)/sqrt(24)*v(1:24,:));
    end 







